//
//  PageControlCollectionViewCell.swift
//  CCPageControl_Swift
//
//  Created by 崔璨 on 2017/10/23.
//  Copyright © 2017年 cccc. All rights reserved.
//

import UIKit

class PageControlCollectionViewCell: UICollectionViewCell {
    
    var imageV : UIImageView?
    
    override init(frame: CGRect) {
        super.init(frame: frame);
        
         imageV = UIImageView(frame: CGRect.init(x: 0, y: 0, width: self.frame.size.width, height: self.frame.size.height))
        
        self.addSubview(imageV!);
    }
    
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}

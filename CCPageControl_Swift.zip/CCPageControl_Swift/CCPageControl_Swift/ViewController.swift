//
//  ViewController.swift
//  CCPageControl_Swift
//
//  Created by 崔璨 on 2017/10/20.
//  Copyright © 2017年 cccc. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
 var saveImageList = [String]()
    override func viewDidLoad() {
        super.viewDidLoad()
        
    //    var select : Int
        
        
        saveImageList.append("image1")
        saveImageList.append("image2")
        saveImageList.append("image3")
        saveImageList.append("image4")
        saveImageList.append("image5")
        
        CCPageControlSwift.SetupPageControlView(imagesList: saveImageList, block: { (pageNum) in
            
            print("第\(pageNum+1)页")
            
        }) {
            print("点击了Button")
        }
            
        
       
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}


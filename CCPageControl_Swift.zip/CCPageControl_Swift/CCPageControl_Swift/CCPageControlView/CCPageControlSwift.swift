//
//  CCPageControlSwift.swift
//  CCPageControl_Swift
//
//  Created by 崔璨 on 2017/10/20.
//  Copyright © 2017年 cccc. All rights reserved.
//

import UIKit

let kScreenWidth = UIScreen.main.bounds.size.width
let kScreenHeight = UIScreen.main.bounds.size.height

let kHighlighted = UIColor.init(red: 230/255.0, green: 230/255.0, blue: 230/255.0, alpha: 1.0)

let kBtnBackgroundColor = UIColor.clear

class CCPageControlSwift:UIView
,UICollectionViewDelegate
,UICollectionViewDataSource,
UICollectionViewDelegateFlowLayout{
    
    //分区数
    func numberOfSectionsInCollectionView(collectionView: UICollectionView) -> Int {
        return 1;
    }

    //每个分区含有的 item 个数
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.imageListCount!;
    }
    
    //每个分区的内边距
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsetsMake(0, 0, 0, 0);
    }
    
    //最小 item 间距
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 0;
    }
    
    //最小行间距
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 0;
    }
    
    //item 的尺寸
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize.init(width: collectionView.frame.size.width, height: collectionView.frame.size.height)
    }

    
    

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {

        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: pageControlCellId, for: indexPath) as! PageControlCollectionViewCell;
        
 
        cell.imageV?.image = UIImage(named: self.imageList![indexPath.row] as! String)
        
        return cell
    }
    

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */
    

    
    var collectionView : UICollectionView?
    
    var pageControl : UIPageControl?
    
    var cancelBtn : UIButton?
    
    
    let pageControlCellId = "cellid"
    
    var imageListCount : Int?
    
    var imageList : Array<Any>?
    

    
    override init(frame: CGRect){

        super.init(frame: frame)
        
        
        
    }
    typealias pageNumBlock = (_ selectIndex : Int) -> Void
    var pageBlock:pageNumBlock?
    
    typealias touchBtnBlock = () -> Void
    var touchBlock:touchBtnBlock?
    
    
    class func SetupPageControlView(imagesList : Array<Any> , block : pageNumBlock? , touchBlock : touchBtnBlock?){
        
        let pageControlView = CCPageControlSwift.init(frame: CGRect.init(x: 0, y:0, width: kScreenWidth, height: kScreenHeight))
        pageControlView.backgroundColor = .red
        UIApplication.shared.keyWindow?.addSubview(pageControlView)
        pageControlView.setValues(imageList: imagesList)
        pageControlView.setupUI()
        pageControlView.pageBlock = block
        pageControlView.touchBlock = touchBlock
    }
    
    func setValues(imageList : Array<Any>) {
        self.imageListCount = imageList.count
        self.imageList = imageList
    }
    
    func setupUI(){
        
        let flowLayout = UICollectionViewFlowLayout()
        flowLayout.scrollDirection = .horizontal
        collectionView = UICollectionView.init(frame: CGRect.init(x: 0, y: 0, width: self.frame.size.width, height: self.frame.size.height),collectionViewLayout:flowLayout)
        collectionView!.backgroundColor = .white
        collectionView!.isPagingEnabled = true
        collectionView!.bounces = false
        collectionView!.delegate = self
        collectionView!.dataSource = self
        collectionView!.showsVerticalScrollIndicator = false
        collectionView!.showsHorizontalScrollIndicator = false
        collectionView!.register(PageControlCollectionViewCell.self, forCellWithReuseIdentifier: pageControlCellId)
        self.addSubview(collectionView!);
        
        
        pageControl = UIPageControl(frame: CGRect.init(x: 0, y: 0, width: self.frame.size.width, height: 30))
        pageControl!.center = CGPoint.init(x: self.frame.size.width/2, y: self.frame.size.height - (pageControl?.frame.size.height)!)
        pageControl!.backgroundColor = .clear
        pageControl!.numberOfPages = self.imageListCount!
        pageControl!.currentPage = 0
        //设置单页时隐藏
        pageControl!.hidesForSinglePage = true
        //设置显示颜色
        pageControl!.currentPageIndicatorTintColor = .green
        //设置页背景指示颜色
        pageControl!.pageIndicatorTintColor = .lightGray
        self.addSubview(pageControl!)
        
        cancelBtn = UIButton(frame:CGRect.init(x: 0, y: 0, width: self.frame.size.width * 0.5, height: self.frame.size.height * 0.08))
        cancelBtn?.center = CGPoint.init(x: self.frame.size.width/2, y: (self.pageControl?.frame.origin.y)! - (self.cancelBtn?.frame.size.height)!/2-10)
        cancelBtn?.backgroundColor = kBtnBackgroundColor
        cancelBtn?.layer.masksToBounds = true
        cancelBtn?.layer.cornerRadius = (cancelBtn?.frame.size.height)!/2
        cancelBtn?.layer.borderWidth = 1.0;
        cancelBtn?.layer.borderColor = UIColor.white.cgColor;
        cancelBtn?.setTitle("立即体验", for: .normal)
        cancelBtn?.addTarget(self, action: #selector(buttonBackGroundHighlighted(_:)), for: .touchDown)
        cancelBtn?.addTarget(self, action: #selector(removeViewBtn(_:)), for: .touchUpInside)
        self.addSubview(cancelBtn!)
        
        if self.imageListCount == 1{
            
            cancelBtn?.isHidden = false
        }
        else
        {
            cancelBtn?.isHidden = true
        }
        
    }
    
    @objc func buttonBackGroundHighlighted(_ btn : UIButton) {
        
        btn.backgroundColor = kHighlighted
    }
    
    @objc func removeViewBtn(_ btn : UIButton) {
        
        btn.backgroundColor = kBtnBackgroundColor
        
        touchBlock?()
        
        self.removeFromSuperview()
    }
    
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        //通过scrollView内容的偏移计算当前显示的是第几页
        let page = Int(scrollView.contentOffset.x / scrollView.frame.size.width)
        //设置pageController的当前页
        pageControl?.currentPage = page
        
        if page == self.imageListCount!-1 {
//            print("最后一页了")
            
        }
        pageBlock?(page)
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        
        if (Int)(scrollView.contentOffset.x/self.frame.size.width) == (self.imageList?.count)!-1{

            cancelBtn?.isHidden = false
        }
            
        else
        {

            cancelBtn?.isHidden = true

        }
        
    }
    
    
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    
    
}
